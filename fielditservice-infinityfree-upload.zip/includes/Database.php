<?php
/**
 * Database Connection - PDO Singleton
 */

class Database {
    private static ?PDO $instance = null;
    
    public static function getInstance(): PDO {
        if (self::$instance === null) {
            try {
                $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $e) {
                error_log('Database connection failed: ' . $e->getMessage());
                $mysqlCode = (int)($e->errorInfo[1] ?? 0);
                $safeMessage = match ($mysqlCode) {
                    1045 => 'Database authentication failed. Verify the database username and password in config/production.php.',
                    1049 => 'Database name was not found. Import the unified database and verify DB_NAME in config/production.php.',
                    2002, 2003 => 'Database host could not be reached. Verify DB_HOST and DB_PORT in config/production.php.',
                    default => 'Database connection failed. Verify the production database configuration.',
                };
                http_response_code(500);
                echo json_encode(['error' => $safeMessage]);
                exit;
            }
        }
        return self::$instance;
    }
    
    public static function query(string $sql, array $params = []): PDOStatement {
        try {
            $stmt = self::getInstance()->prepare($sql);
        } catch (PDOException $e) {
            // A long-lived PHP worker can retain a stale MySQL connection.
            // Retrying a failed prepare is safe because no statement ran yet.
            $mysqlCode = (int)($e->errorInfo[1] ?? 0);
            if (!in_array($mysqlCode, [2006, 2013], true)) {
                throw $e;
            }
            self::$instance = null;
            $stmt = self::getInstance()->prepare($sql);
        }
        $stmt->execute($params);
        return $stmt;
    }

    /** Execute a statement when no result rows are needed. */
    public static function execute(string $sql, array $params = []): int {
        return self::query($sql, $params)->rowCount();
    }
    
    public static function fetch(string $sql, array $params = []): ?array {
        $stmt = self::query($sql, $params);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    public static function fetchAll(string $sql, array $params = []): array {
        $stmt = self::query($sql, $params);
        return $stmt->fetchAll();
    }
    
    public static function insert(string $table, array $data): int {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        self::query($sql, array_values($data));
        return (int) self::getInstance()->lastInsertId();
    }
    
    public static function update(string $table, array $data, string $where, array $whereParams = []): int {
        $set = implode(', ', array_map(fn($col) => "{$col} = ?", array_keys($data)));
        $sql = "UPDATE {$table} SET {$set} WHERE {$where}";
        $params = array_merge(array_values($data), $whereParams);
        $stmt = self::query($sql, $params);
        return $stmt->rowCount();
    }
    
    public static function delete(string $table, string $where, array $params = []): int {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        $stmt = self::query($sql, $params);
        return $stmt->rowCount();
    }
    
    public static function count(string $table, string $where = '1', array $params = []): int {
        $sql = "SELECT COUNT(*) as cnt FROM {$table} WHERE {$where}";
        $result = self::fetch($sql, $params);
        return (int)($result['cnt'] ?? 0);
    }
}
