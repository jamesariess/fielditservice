<?php
// Local secrets — gitignored, never commit real keys.
if (!defined('OPENAI_API_KEY')) {
    define('OPENAI_API_KEY', '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');
}
